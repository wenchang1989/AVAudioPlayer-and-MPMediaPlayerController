//
//  ViewController.m
//  CWCRemotionControl
//
//  Created by CWC on 15/12/22.
//  Copyright © 2015年 SouFun. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MPMediaItem.h>
#import <MediaPlayer/MPNowPlayingInfoCenter.h>
#import <MediaPlayer/MPMusicPlayerController.h>
#import <MediaPlayer/MPVolumeView.h>


#define SONGCOUNT 7

@interface ViewController ()<AVAudioPlayerDelegate>

@property (nonatomic, strong) UIButton *playButton;
@property (nonatomic, assign) BOOL isPlaying;
@property (nonatomic, strong) AVAudioPlayer *player;
@property (nonatomic, copy) NSString *playString;

@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, strong) NSArray *songArray;

@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) UISlider *slider;

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, strong) MPMusicPlayerController *musicPlyerVC;

@property (nonatomic, strong) UISlider *voiceSlider;


@property (nonatomic, strong) NSTimer *puickTimer;//记录快进和快退的时间
@property (nonatomic, assign) CGFloat tapTime;//快进快退时间

@property (nonatomic, assign) BOOL isQuick;//快进还是快退

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    self.songArray = @[@"1",@"2",@"3",@"4",@"5",@"6",@"0"];
    
    NSString *str = [[NSBundle mainBundle] pathForResource:@"1" ofType:@"mp3"];
    self.playString = str;
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:self.playString] error:nil];
    //    [self.player prepareToPlay];
    
    self.player.delegate = self;
    
//    self.player.numberOfLoops = -1;//单曲回放
    
    [self.player prepareToPlay];
    
//    [self.player play];
//    
//    self.isPlaying = YES;
    //记录播放时间
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(sliderValueChange) userInfo:nil repeats:YES];
    
    self.timer = timer;
    
    [self.timer setFireDate:[NSDate distantFuture]];
    
    //记录快进快退时间
    NSTimer *quickTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(tapKeepTime) userInfo:nil repeats:YES];
    [quickTimer setFireDate:[NSDate distantFuture]];
    self.puickTimer = quickTimer;
    
    
    self.musicPlyerVC = [MPMusicPlayerController applicationMusicPlayer];
    [self initLayOut];
}

- (void)viewDidAppear:(BOOL)animated{

    [super viewDidAppear:animated];

    [self becomeFirstResponder];
    
    [self configNowPlayingInfoCenter];
    
    self.voiceSlider.value = self.musicPlyerVC.volume;
    
    MPVolumeView *volumeView = [[MPVolumeView alloc] initWithFrame:CGRectMake(-1000, 30, 100, 100)];
    [volumeView setHidden:NO];
    [self.view addSubview:volumeView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(voiceChange:) name:@"AVSystemController_SystemVolumeDidChangeNotification" object:nil];
    
}

#pragma mark=随着系统声音改变
- (void)voiceChange:(NSNotification *)notification{

    self.voiceSlider.value = self.musicPlyerVC.volume;
    
}

- (void)viewWillDisappear:(BOOL)animated{

    [super viewWillDisappear:animated];
    
    [self resignFirstResponder];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"AVSystemController_SystemVolumeDidChangeNotification" object:nil];
    
}
/*
 typedef NS_ENUM(NSInteger, UIEventSubtype) {
 // 不包含任何子事件类型
 UIEventSubtypeNone                              = 0,
 
 // 摇晃事件（从iOS3.0开始支持此事件）
 UIEventSubtypeMotionShake                       = 1,
 
 //远程控制子事件类型（从iOS4.0开始支持远程控制事件）
 //播放事件【操作：停止状态下，按耳机线控中间按钮一下】
 UIEventSubtypeRemoteControlPlay                 = 100,
 //暂停事件
 UIEventSubtypeRemoteControlPause                = 101,
 //停止事件
 UIEventSubtypeRemoteControlStop                 = 102,
 //播放或暂停切换【操作：播放或暂停状态下，按耳机线控中间按钮一下】
 UIEventSubtypeRemoteControlTogglePlayPause      = 103,
 //下一曲【操作：按耳机线控中间按钮两下】
 UIEventSubtypeRemoteControlNextTrack            = 104,
 //上一曲【操作：按耳机线控中间按钮三下】
 UIEventSubtypeRemoteControlPreviousTrack        = 105,
 //快退开始【操作：按耳机线控中间按钮三下不要松开】
 UIEventSubtypeRemoteControlBeginSeekingBackward = 106,
 //快退停止【操作：按耳机线控中间按钮三下到了快退的位置松开】
 UIEventSubtypeRemoteControlEndSeekingBackward   = 107,
 //快进开始【操作：按耳机线控中间按钮两下不要松开】
 UIEventSubtypeRemoteControlBeginSeekingForward  = 108,
 //快进停止【操作：按耳机线控中间按钮两下到了快进的位置松开】
 UIEventSubtypeRemoteControlEndSeekingForward    = 109,
 };
 */
#pragma mark= 远程控制事件
- (void)remoteControlReceivedWithEvent:(UIEvent *)event{

    NSLog(@"%ld,%ld",(long)event.type,(long)event.subtype);
    if (event.type == UIEventTypeRemoteControl) {
        switch (event.subtype) {
            case UIEventSubtypeMotionShake:
                [self nextClick:nil];
                
                break;
            case UIEventSubtypeRemoteControlPlay:
                [self.player play];
                self.isPlaying = YES;
                
                [self.timer setFireDate:[NSDate date]];
                
                [self configNowPlayingInfoCenter];
                
                break;
            case UIEventSubtypeRemoteControlPause:
                [self.player pause];
                self.isPlaying = NO;
                
                [self.timer setFireDate:[NSDate distantFuture]];
                
                
                
                break;
            case UIEventSubtypeRemoteControlStop:
                [self.player stop];
                self.isPlaying = NO;
                break;
            case UIEventSubtypeRemoteControlTogglePlayPause:
                if (self.isPlaying) {
                    [self.player pause];
                    [self.timer setFireDate:[NSDate distantFuture]];
                }else{
                    [self.player play];
                    [self.timer setFireDate:[NSDate date]];
                }
                self.isPlaying = !self.isPlaying;
                break;
            case UIEventSubtypeRemoteControlNextTrack:
                NSLog(@"next========");
                
                [self nextClick:nil];
                
                break;
            case UIEventSubtypeRemoteControlPreviousTrack:
                NSLog(@"previous =======");
                
                [self lastClick:nil];
                
                break;
            case UIEventSubtypeRemoteControlBeginSeekingForward:
                NSLog(@"begin seeking forward");
                
                self.isQuick = YES;
                [self.player pause];
                [self.timer setFireDate:[NSDate distantFuture]];
                [self.puickTimer setFireDate:[NSDate date]];
                
                break;
            case UIEventSubtypeRemoteControlEndSeekingForward:
                NSLog(@"end seeking forward");
                if (self.player.currentTime + self.tapTime >= self.player.duration) {
                    [self.puickTimer setFireDate:[NSDate distantFuture]];
                    [self nextClick:nil];
                }else{
                    
                    
                    self.player.currentTime = self.player.currentTime + self.tapTime;
                    
                    self.tapTime = 0;
                    
                    [self.player play];
                    [self.timer setFireDate:[NSDate date]];
                    [self.puickTimer setFireDate:[NSDate distantFuture]];
                    
                }
                break;
            case UIEventSubtypeRemoteControlBeginSeekingBackward:
                NSLog(@"begin seeking back");
                
                self.isQuick = NO;
                [self.player pause];
                [self.timer setFireDate:[NSDate distantFuture]];
                [self.puickTimer setFireDate:[NSDate date]];
                
                break;
            case UIEventSubtypeRemoteControlEndSeekingBackward:
                NSLog(@"end seeking back");
                
                if (self.player.currentTime <= self.tapTime) {
                    [self.puickTimer setFireDate:[NSDate distantFuture]];
                    [self lastClick:nil];
                }else{
                    
                    
                    self.player.currentTime = self.player.currentTime - self.tapTime;
                    
                    self.tapTime = 0;
                    
                    [self.player play];
                    [self.timer setFireDate:[NSDate date]];
                    [self.puickTimer setFireDate:[NSDate distantFuture]];
                    
                }

                
                break;
            default:
                break;
        }
        
        [self changeUIState];
        
    }
}
//快进快退
-(void)tapKeepTime{

    self.tapTime = self.tapTime + 2;
    if (self.isQuick) {
        self.slider.value = self.slider.value + 2;
    }else{
    
        self.slider.value -= 2;
        
    }
    
}

//摇一摇换曲
- (void)motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event{

    [self nextClick:nil];
    
}


#pragma mark=AVAudioPlayerDelegate
//播放结束时
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{

    [self nextClick:nil];
    
}

/* if an error occurs while decoding it will be reported to the delegate. */
//解码失败
- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError * __nullable)error{

    if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
        
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"解码失败" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    
    [alertVC addAction:action];
    
    [self presentViewController:alertVC animated:YES completion:nil];
        
        return;
    }
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"解码失败" message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    
    [alertView show];
    
}

//遇到外界打断
- (void)audioPlayerBeginInterruption:(AVAudioPlayer *)player{

    if (self.isPlaying == YES) {
        [self.player pause];
        self.isPlaying = NO;
        [self.timer setFireDate:[NSDate distantFuture]];
        [self changeUIState];
    }
    
}

#pragma mark=界面布局
- (void)initLayOut{

    //专辑封面
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    imageView.image = [UIImage imageNamed:@"ceshi.jpg"];
    imageView.contentMode = UIViewContentModeScaleAspectFill;
    imageView.tag = 7238;
    imageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showTheView:)];
    [imageView addGestureRecognizer:tap];
    self.imageView = imageView;
    
    [self.view addSubview:imageView];
    
    
    
    //播放控制面板
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height-88, [UIScreen mainScreen].bounds.size.width, 88)];
    view.backgroundColor = [UIColor lightGrayColor];
    view.alpha = 0.8;
    view.tag = 1234;
    [self.view addSubview:view];
    
    //添加播放按钮
    self.playButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.playButton.bounds = CGRectMake(0, 0, 30, 30);
    [self.playButton setImage:[UIImage imageNamed:@"bfzn_004.png"] forState:UIControlStateNormal];
    [self.playButton setImage:[UIImage imageNamed:@"bfzn_006.png"] forState:UIControlStateHighlighted];
    self.playButton.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, 55);
    
    [self.playButton addTarget:self action:@selector(butClick:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:self.playButton];
    
    //添加下一曲和上一曲按钮
    UIButton *nextBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    nextBtn.bounds = CGRectMake(0, 0, 30, 30);
    [nextBtn setImage:[UIImage imageNamed:@"bfzn_007.png"] forState:UIControlStateNormal];
    nextBtn.center = CGPointMake([UIScreen mainScreen].bounds.size.width/4*3, 55);
    
    [nextBtn addTarget:self action:@selector(nextClick:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:nextBtn];
    
    UIButton *lastBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    lastBtn.bounds = CGRectMake(0, 0, 30, 30);
    [lastBtn setImage:[UIImage imageNamed:@"bfzn_005.png"] forState:UIControlStateNormal];
    lastBtn.center = CGPointMake([UIScreen mainScreen].bounds.size.width/4, 55);
    
    [lastBtn addTarget:self action:@selector(lastClick:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:lastBtn];
    
    //播放进度条
    UISlider *timeSlider = [[UISlider alloc] initWithFrame:CGRectMake(20, 20, [UIScreen mainScreen].bounds.size.width-40, 2)];
    
    [timeSlider setThumbImage:[self imageWithColer:[UIColor redColor]] forState:UIControlStateNormal];
    
    [timeSlider setThumbImage:[self imageWithColer:[UIColor blueColor]] forState:UIControlStateHighlighted];
    
    [timeSlider setMinimumTrackTintColor:[UIColor cyanColor]];
    
    [timeSlider setContinuous:NO];
    
    timeSlider.minimumValue = 0;
    timeSlider.value = 0;
    timeSlider.maximumValue = self.player.duration;
    self.slider = timeSlider;
    
    
    [timeSlider addTarget:self action:@selector(valueChang:) forControlEvents:UIControlEventValueChanged];
    
//    [timeSider setThumbImage:[UIImage imageNamed:@"bfzn_005.png"] forState:UIControlStateNormal];
    
    [view addSubview:timeSlider];
    
    
   // 音量
    UISlider *voiceSlider = [[UISlider alloc] initWithFrame:CGRectMake(30, 30, [UIScreen mainScreen].bounds.size.width- 60, 4)];
    [voiceSlider setThumbImage:[self imageWithColer:[UIColor yellowColor]] forState:UIControlStateNormal];
    [voiceSlider setThumbImage:[self imageWithColer:[UIColor orangeColor]] forState:UIControlStateHighlighted];
    
    [timeSlider setMinimumTrackTintColor:[UIColor cyanColor]];
    [voiceSlider setMaximumTrackTintColor:[UIColor grayColor]];
    
    [voiceSlider setContinuous:NO];
    
    voiceSlider.minimumValue = 0.1;
    
    voiceSlider.value = self.musicPlyerVC.volume;
    [voiceSlider addTarget:self action:@selector(voiceChangged:) forControlEvents:UIControlEventValueChanged];
    self.voiceSlider = voiceSlider;
    
    [self.imageView addSubview:voiceSlider];
    
    [self addLabelWithStr:@"-" andFont:12 andRect:CGRectMake(10, 30, 10, 10) andColer:[UIColor whiteColor] andAlgent:NSTextAlignmentCenter andSuperView:self.imageView];
    
    [self addLabelWithStr:@"+" andFont:12 andRect:CGRectMake([UIScreen mainScreen].bounds.size.width-20, 30, 10, 10) andColer:[UIColor whiteColor] andAlgent:NSTextAlignmentCenter andSuperView:self.imageView];
    
}



#pragma mark==声音控制
- (void)voiceChangged:(UISlider *)sender{

    self.musicPlyerVC.volume = sender.value;
    
}

#pragma mark=添加label
- (void)addLabelWithStr:(NSString *)string andFont:(CGFloat)font andRect:(CGRect)rect andColer:(UIColor *)coler andAlgent:(NSTextAlignment)alignment andSuperView:(UIView *)view{

    UILabel *label = [[UILabel alloc] initWithFrame:rect];
    label.text = string;
    label.textColor = coler;
    label.font = [UIFont systemFontOfSize:font];
    label.textAlignment = alignment;
    
    [view addSubview:label];
    
}
#pragma mark=屏幕的点击事件
- (void)showTheView:(UITapGestureRecognizer *)sender{

//    UIImageView *imageView = (UIImageView *)[self.view viewWithTag:7238];
    UIView *view = [self.view viewWithTag:1234];
    if (self.imageView.tag == 7238) {
        [UIView animateWithDuration:.5 animations:^{
            [view setFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 88)];
        }];
        
        self.imageView.tag = 1000;
        
    }else{
    
        [UIView animateWithDuration:.5 animations:^{
            [view setFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 88, [UIScreen mainScreen].bounds.size.width, 88)];
        }];
        
        self.imageView.tag = 7238;
        
    }
    
}

#pragma mark=后台显示图片和名称
- (void)configNowPlayingInfoCenter{

    if (NSClassFromString(@"MPNowPlayingInfoCenter")) {
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        [dict setObject:@"真的爱你" forKey:MPMediaItemPropertyTitle];//歌名
        [dict setObject:@"陈文昌" forKey:MPMediaItemPropertyArtist];//歌手
        [dict setObject:@"清风至上" forKey:MPMediaItemPropertyAlbumTitle];//专辑
        
        UIImage *image = [UIImage imageNamed:@"昌.jpg"];//歌手图片
        MPMediaItemArtwork *artwork = [[MPMediaItemArtwork alloc] initWithImage:image];
        
        [dict setObject:artwork forKey:MPMediaItemPropertyArtwork];
        
        [dict setObject:[NSNumber numberWithFloat:self.player.currentTime] forKey:MPNowPlayingInfoPropertyElapsedPlaybackTime];
        
        [dict setObject:[NSNumber numberWithFloat:0.1] forKey:MPNowPlayingInfoPropertyDefaultPlaybackRate];
        
        [dict setObject:[NSNumber numberWithFloat:self.player.duration] forKey:MPMediaItemPropertyPlaybackDuration];
        
        [[MPNowPlayingInfoCenter defaultCenter] setNowPlayingInfo:dict];
        
    }
    
}
#pragma mark=播放进度条
- (void)sliderValueChange{

    self.slider.maximumValue = self.player.duration;
    self.slider.value = self.slider.value+ 0.1;
    
}

#pragma mark=滑块拖动
- (void)valueChang:(UISlider *)sender{

    self.player.currentTime = sender.value;
    if (!self.isPlaying) {
        [self.player play];
        self.isPlaying = YES;
        [self.timer setFireDate:[NSDate date]];
    }
    [self configNowPlayingInfoCenter];
    
}

- (UIImage *)imageWithColer:(UIColor *)coler{

    CGRect rect = CGRectMake(0, 0, 5, 5);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, coler.CGColor);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

#pragma mark=制作图片
-(UIImage*) OriginImage:(UIImage*)image scaleToSize:(CGSize)size

{
    
    UIGraphicsBeginImageContext(size);//size为CGSize类型，即你所需要的图片尺寸
    
    [image drawInRect:CGRectMake(0,0, size.width, size.height)];
    
    UIImage* scaledImage =UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return scaledImage;
    
}
#pragma mark=歌曲切换
- (void)nextClick:(UIButton *)sender{

    [self.player stop];
    
    self.player = nil;
    
    self.currentIndex = (self.currentIndex + 1)%SONGCOUNT;
    
    self.playString = [[NSBundle mainBundle] pathForResource:self.songArray[self.currentIndex] ofType:@"mp3"];
    
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:self.playString] error:NULL];
    
    self.player.delegate = self;
    
    [self.player prepareToPlay];
    
    [self.player play];
    
    self.isPlaying = YES;
    
    [self changeUIState];
    
    self.slider.value = 0;
    [self.timer setFireDate:[NSDate date]];
    
    [self configNowPlayingInfoCenter];
    
}
- (void)lastClick:(UIButton *)sender{

    [self.player stop];
    
    self.player = nil;
    
    self.currentIndex = (self.currentIndex - 1 + SONGCOUNT)%SONGCOUNT;
    
    self.playString = [[NSBundle mainBundle] pathForResource:self.songArray[self.currentIndex] ofType:@"mp3"];
    
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:self.playString] error:NULL];
    
    self.player.delegate = self;
    
    [self.player prepareToPlay];
    
    [self.player play];
    
    self.isPlaying = YES;
    
    [self changeUIState];
    
    self.slider.value = 0;
    [self.timer setFireDate:[NSDate date]];
    
}
#pragma mark=click event
- (void)butClick:(UIButton *)sender{

    if (self.isPlaying) {
        [self.player pause];
        
        [self.timer setFireDate:[NSDate distantFuture]];
        
    }else{
    
        [self.player play];
        [self.timer setFireDate:[NSDate date]];
    }
    self.isPlaying = !self.isPlaying;
    
    [self changeUIState];
    
}
#pragma mark=界面状态
- (void)changeUIState{

    if (self.isPlaying) {
        [self.playButton setImage:[UIImage imageNamed:@"bfzn_003.png"] forState:UIControlStateNormal];
        [self.playButton setImage:[UIImage imageNamed:@"bfzn_006.png"] forState:UIControlStateHighlighted];
    }else{
    
        [self.playButton setImage:[UIImage imageNamed:@"bfzn_004.png"] forState:UIControlStateNormal];
        [self.playButton setImage:[UIImage imageNamed:@"bfzn_006.png"] forState:UIControlStateHighlighted];
        
    }
    
}

- (BOOL)canBecomeFirstResponder{

    return YES;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
