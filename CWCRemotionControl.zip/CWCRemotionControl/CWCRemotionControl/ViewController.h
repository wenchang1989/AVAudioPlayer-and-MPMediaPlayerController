//
//  ViewController.h
//  CWCRemotionControl
//
//  Created by CWC on 15/12/22.
//  Copyright © 2015年 SouFun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

